import { defineConfig } from "vite";

export default defineConfig({
  server: {
    port: 3000, // Vous pouvez changer le port si nécessaire
  },
});
